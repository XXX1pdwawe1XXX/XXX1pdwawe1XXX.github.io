var score =0;
var lives =3;
var level =0;

//The game clicker
onEvent("touchable", "click", function(event) {
setPosition("touchable", randomNumber(50,280), randomNumber(50, 350));
for (var i = 0; i < 100; i++) {
  playSound("assets/SKULL TRUMPET.mp3", false);
}
score=score+1;
setText("pad",score)
  //Changes to win screen  
  if (score == 10) {
    setScreen("win");
    score = 0;
    setText("pad",score);
    level=level+1;
    setText("lvl",level);
    setText("lvl2",level);
  }

  
  
});

//Start Button
onEvent("start", "click", function(event) {
  setScreen("game");
  lives = 3;
  setText("pad2",lives);
  score=0;
  setText("pad",score);
  
});
//Obstacle background
onEvent("background", "click", function(event) {
  
  lives=lives-1;
  setText("pad2",lives);
    //Generates Loss
if (lives==0){
  setScreen("loss");
};
});
//Restart Lose
onEvent("restart", "click", function(event) {
  setScreen("mainscreen");
  lives = 3;
  setText("pad2",lives);
});
//Restart win
onEvent("again", "click", function(event) {
  setScreen("mainscreen");
});


//Name Entry
onEvent("text_input1", "input", function(event) {
  console.log("First Name current text: " + getText("text_input1"));
});
onEvent("3#'s", "input", function(event) {
  console.log("Last Name: " + getText("3#'s"));

});

  


//Art




//Function to draw the Sky
function drawSky() {
  moveTo(160, 225);
  penRGB(226, 96, 15);
  dot(400);
}
//Function to draw birds with a parameter to set the amount
hide();
function drawBird(amount) {
  for (var i = 0; i < amount; i++) {
    moveTo(randomNumber(160, 320), randomNumber(0, 200));
    penDown();
    penColor("black");
    turnTo(0);
    arcRight(180, 10);
    turnTo(0);
    arcLeft(180, 10);
    turnTo(0);
    arcLeft(180, 10);
    penUp();
  }
}
//Function to draw the tree
function drawTree() {
  penUp();
  moveTo(250, 350);
  turnTo(0);
  drawTrunk();
  drawLeaves(300);
}
//Function to draw the tree’s trunk
function drawTrunk() {
  penRGB(139, 69, 19);
  penWidth(15);
  penDown();
  moveForward(100);
}
//Function to draw the leaves of the tree with parameter for amount of leaves
function drawLeaves(amount) {
  for (var i = 0; i < amount; i++) {
    penUp();
    moveTo(randomNumber(200, 300), randomNumber(200, 275));
    penDown();
    penRGB(randomNumber(100, 200), randomNumber(0, 100), 0, 0.5);
    dot(5);
  }
}
//Function to draw the grass/ground
function drawGround() {
  penUp();
  penRGB(25, 102, 2);
  moveTo(0, 350);
  penDown();
  penWidth(5);
  turnTo(90);
  for (var i = 0; i < 100; i++) {
    moveForward(320);
    turnRight(90);
    moveForward(5);
    turnRight(90);
    moveForward(320);
    turnLeft(90);
    moveForward(5);
    turnLeft(90);
  }
}
//Function with parameter to draw pumpkins and change the amount
function drawPumpkin(amount) {
  for (var i = 0; i < amount; i++) {
    turnTo(0);
    penUp();
    moveTo(randomNumber(0, 160), randomNumber(0, 300));
    penRGB(255, 165, 0);
    penDown();
    dot(30);
    penUp();
    moveForward(5);
    turnLeft(90);
    moveForward(10);
    penColor("black");
    dot(5);
    turnRight(180);
    moveForward(20);
    dot(5);
    moveForward(15);
    turnLeft(90);
    turnLeft(180);
    penDown();
    penWidth(1);
    arcRight(180, 25);
  }
}
//Call all the functions so that the picture is drawn
drawSky();
drawBird(5);
drawGround();
drawTree();
drawPumpkin(3);

